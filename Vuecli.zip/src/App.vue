<template>
  <div id="app">
    <img src="./assets/logo.png">
    <router-view/>
    <mt-button type="default">default</mt-button>
    <mt-button type="primary" @click="tip">primary</mt-button>
    <mt-button type="danger">danger</mt-button>
  </div>
</template>

<script>
import { Toast } from "mint-ui";
export default {
  //es6导出对象的写法
  name: "App",
  methods: {
    tip() {
      Toast({
        message: "测试哈哈哈哈",
        position: " center",
        duration: 1000,
        iconClass: 'icon icon-success'
      });
    }
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
